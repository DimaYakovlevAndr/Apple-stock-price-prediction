```python
# Описание
# скрипт использует LSTM для предсказания цены закрытия по акции $AAPL на основании данных за предыдущие 60 дней
```


```python
# импорт библиотек
import math
import pandas as pd
import numpy as np
import pandas_datareader as web
import sklearn
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential 
from keras.layers import Dense, LSTM
import matplotlib.pyplot as plt
plt.style.use('fivethirtyeight')
```


```python
# получение данных 
df = web.DataReader('AAPL', data_source='yahoo', start='2011-01-01', end='2021-03-14')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2011-01-03</th>
      <td>11.795000</td>
      <td>11.601429</td>
      <td>11.630000</td>
      <td>11.770357</td>
      <td>445138400.0</td>
      <td>10.138556</td>
    </tr>
    <tr>
      <th>2011-01-04</th>
      <td>11.875000</td>
      <td>11.719643</td>
      <td>11.872857</td>
      <td>11.831786</td>
      <td>309080800.0</td>
      <td>10.191467</td>
    </tr>
    <tr>
      <th>2011-01-05</th>
      <td>11.940714</td>
      <td>11.767857</td>
      <td>11.769643</td>
      <td>11.928571</td>
      <td>255519600.0</td>
      <td>10.274836</td>
    </tr>
    <tr>
      <th>2011-01-06</th>
      <td>11.973214</td>
      <td>11.889286</td>
      <td>11.954286</td>
      <td>11.918929</td>
      <td>300428800.0</td>
      <td>10.266529</td>
    </tr>
    <tr>
      <th>2011-01-07</th>
      <td>12.012500</td>
      <td>11.853571</td>
      <td>11.928214</td>
      <td>12.004286</td>
      <td>311931200.0</td>
      <td>10.340052</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2021-03-08</th>
      <td>121.000000</td>
      <td>116.209999</td>
      <td>120.930000</td>
      <td>116.360001</td>
      <td>153918600.0</td>
      <td>116.360001</td>
    </tr>
    <tr>
      <th>2021-03-09</th>
      <td>122.059998</td>
      <td>118.790001</td>
      <td>119.029999</td>
      <td>121.089996</td>
      <td>129159600.0</td>
      <td>121.089996</td>
    </tr>
    <tr>
      <th>2021-03-10</th>
      <td>122.169998</td>
      <td>119.449997</td>
      <td>121.690002</td>
      <td>119.980003</td>
      <td>111760400.0</td>
      <td>119.980003</td>
    </tr>
    <tr>
      <th>2021-03-11</th>
      <td>123.209999</td>
      <td>121.260002</td>
      <td>122.540001</td>
      <td>121.959999</td>
      <td>102753600.0</td>
      <td>121.959999</td>
    </tr>
    <tr>
      <th>2021-03-12</th>
      <td>121.169998</td>
      <td>119.160004</td>
      <td>120.400002</td>
      <td>121.029999</td>
      <td>87963400.0</td>
      <td>121.029999</td>
    </tr>
  </tbody>
</table>
<p>2565 rows × 6 columns</p>
</div>




```python
# разведочный анализ
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2565.000000</td>
      <td>2565.000000</td>
      <td>2565.000000</td>
      <td>2565.000000</td>
      <td>2.565000e+03</td>
      <td>2565.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>38.375475</td>
      <td>37.570539</td>
      <td>37.978782</td>
      <td>37.986416</td>
      <td>2.526082e+08</td>
      <td>36.269919</td>
    </tr>
    <tr>
      <th>std</th>
      <td>27.755741</td>
      <td>26.969935</td>
      <td>27.389436</td>
      <td>27.374905</td>
      <td>1.994599e+08</td>
      <td>27.944334</td>
    </tr>
    <tr>
      <th>min</th>
      <td>11.346429</td>
      <td>11.089286</td>
      <td>11.310000</td>
      <td>11.261429</td>
      <td>4.544800e+07</td>
      <td>9.700181</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>20.079643</td>
      <td>19.702856</td>
      <td>19.850357</td>
      <td>19.859644</td>
      <td>1.135284e+08</td>
      <td>17.433689</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>28.842501</td>
      <td>28.312500</td>
      <td>28.485001</td>
      <td>28.514999</td>
      <td>1.808720e+08</td>
      <td>26.455313</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>45.597500</td>
      <td>44.542500</td>
      <td>45.072498</td>
      <td>44.992500</td>
      <td>3.296664e+08</td>
      <td>43.993488</td>
    </tr>
    <tr>
      <th>max</th>
      <td>145.089996</td>
      <td>141.369995</td>
      <td>143.600006</td>
      <td>143.160004</td>
      <td>1.880998e+09</td>
      <td>142.946396</td>
    </tr>
  </tbody>
</table>
</div>




```python
# визуализация
plt.figure(figsize=(20,15))
plt.title('Close_Price_History')
plt.plot(df['Close'])
plt.xlabel('Date', fontsize=20)
plt.ylabel('Close_price_USD',fontsize=20)
```




    Text(0, 0.5, 'Close_price_USD')




    
![png](output_4_1.png)
    



```python
# создание фрэйма только с колонкой 'Close'
data = df.filter(['Close'])
# переводим data в numpy array
dataset = data.values
# отбираем строки для тренировки (80%)
training_data_len = math.ceil( len(dataset) * .8)
```


```python
# масштабирование данных
scaler = MinMaxScaler(feature_range=(0,1))
scaled_data = scaler.fit_transform(dataset)
scaled_data
```




    array([[0.00385848],
           [0.00432421],
           [0.00505799],
           ...,
           [0.8242589 ],
           [0.8392704 ],
           [0.83221953]])




```python
# создание тренировочного датасета
train_data = scaled_data[0:training_data_len , :]
# сплит сетов в x_train и y_train
x_train = []
y_train = []

for i in range(60, len(train_data)):
    x_train.append(train_data[i-60:i, 0])
    y_train.append(train_data[i,0])
    if i<= 61:
        print(x_train)
        print(y_train)
        print()
```

    [array([0.00385848, 0.00432421, 0.00505799, 0.00498489, 0.00563203,
           0.00734601, 0.00712669, 0.00787942, 0.0082206 , 0.00897876,
           0.00685862, 0.00636853, 0.00470058, 0.00308679, 0.00599216,
           0.0070617 , 0.00772509, 0.00755179, 0.00562661, 0.0064985 ,
           0.0080446 , 0.00785235, 0.00761407, 0.00844263, 0.00989938,
           0.01079833, 0.01159982, 0.01061963, 0.01124511, 0.01187601,
           0.01207096, 0.01294556, 0.01163773, 0.00954197, 0.00630625,
           0.00739205, 0.00746244, 0.00889211, 0.01025951, 0.0092035 ,
           0.00996436, 0.0119789 , 0.01209804, 0.01084167, 0.01094997,
           0.01005913, 0.00848866, 0.00992916, 0.01035427, 0.00815291,
           0.00397762, 0.0052313 , 0.00415633, 0.00649308, 0.00700754,
           0.0064633 , 0.00802835, 0.00980732, 0.00950946, 0.00965027])]
    [0.00901936926957736]
    
    [array([0.00385848, 0.00432421, 0.00505799, 0.00498489, 0.00563203,
           0.00734601, 0.00712669, 0.00787942, 0.0082206 , 0.00897876,
           0.00685862, 0.00636853, 0.00470058, 0.00308679, 0.00599216,
           0.0070617 , 0.00772509, 0.00755179, 0.00562661, 0.0064985 ,
           0.0080446 , 0.00785235, 0.00761407, 0.00844263, 0.00989938,
           0.01079833, 0.01159982, 0.01061963, 0.01124511, 0.01187601,
           0.01207096, 0.01294556, 0.01163773, 0.00954197, 0.00630625,
           0.00739205, 0.00746244, 0.00889211, 0.01025951, 0.0092035 ,
           0.00996436, 0.0119789 , 0.01209804, 0.01084167, 0.01094997,
           0.01005913, 0.00848866, 0.00992916, 0.01035427, 0.00815291,
           0.00397762, 0.0052313 , 0.00415633, 0.00649308, 0.00700754,
           0.0064633 , 0.00802835, 0.00980732, 0.00950946, 0.00965027]), array([0.00432421, 0.00505799, 0.00498489, 0.00563203, 0.00734601,
           0.00712669, 0.00787942, 0.0082206 , 0.00897876, 0.00685862,
           0.00636853, 0.00470058, 0.00308679, 0.00599216, 0.0070617 ,
           0.00772509, 0.00755179, 0.00562661, 0.0064985 , 0.0080446 ,
           0.00785235, 0.00761407, 0.00844263, 0.00989938, 0.01079833,
           0.01159982, 0.01061963, 0.01124511, 0.01187601, 0.01207096,
           0.01294556, 0.01163773, 0.00954197, 0.00630625, 0.00739205,
           0.00746244, 0.00889211, 0.01025951, 0.0092035 , 0.00996436,
           0.0119789 , 0.01209804, 0.01084167, 0.01094997, 0.01005913,
           0.00848866, 0.00992916, 0.01035427, 0.00815291, 0.00397762,
           0.0052313 , 0.00415633, 0.00649308, 0.00700754, 0.0064633 ,
           0.00802835, 0.00980732, 0.00950946, 0.00965027, 0.00901937])]
    [0.00901936926957736, 0.008986883257433825]
    
    


```python
# конвертация x_train and y_train в numpy arrays
x_train, y_train = np.array(x_train), np.array(y_train)
```


```python
# изменяет датасет для LSTM
x_train = np.reshape(x_train, (x_train.shape[0],x_train.shape[1],1))
x_train.shape
```




    (1992, 60, 1)




```python
# построение LSTM модели
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape = (x_train.shape[1], 1)))
model.add(LSTM(50,return_sequences=False))
model.add(Dense(25))
model.add(Dense(1))
```


```python
# оптицизация
model.compile(optimizer='adam', loss='mean_squared_error')
```


```python
# тренировка модели
model.fit(x_train, y_train, batch_size=1, epochs=1)
```

    1992/1992 [==============================] - 85s 39ms/step - loss: 3.2392e-04
    




    <tensorflow.python.keras.callbacks.History at 0x1c435c45ee0>




```python
# создание тестового датасета
test_data = scaled_data[training_data_len - 60: , :]
x_test = []
y_test = dataset[training_data_len: , :]
for i in range(60, len(test_data)):
    x_test.append(test_data[i-60:i, 0])
```


```python
# перевод в array
x_test = np.array(x_test)
```


```python
 # изменяет датасет для LSTM
x_test = np.reshape(x_test, (x_test.shape[0],x_test.shape[1],1))
x_test.shape
```




    (513, 60, 1)




```python
# получение предсказанных значений
predictions = model.predict(x_test)
predictions = scaler.inverse_transform(predictions)
```


```python
# получение RMSE модели (Среднеквадратическая ошибка)
rmse = np.sqrt( np.mean( predictions - y_test) **2 )
rmse
```




    10.057691391913282




```python
# графики
train = data[:training_data_len]
valid = data[training_data_len:]
valid['Predictions'] = predictions
plt.figure(figsize=(20,15))
plt.title('AAPL prediction')
plt.xlabel('Date', fontsize=18)
plt.ylabel('Close price USD', fontsize=18)
plt.plot(train['Close'])
plt.plot(valid[['Close', 'Predictions']])
plt.legend(['Train', 'Val', 'Predictions'], loc='lower right')

```

    <ipython-input-19-d76054bb5691>:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      valid['Predictions'] = predictions
    




    <matplotlib.legend.Legend at 0x1c436199e20>




    
![png](output_18_2.png)
    



```python
# сравнение цен: фактической и предсказанной
valid
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
      <th>Predictions</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-03-01</th>
      <td>43.742500</td>
      <td>39.837856</td>
    </tr>
    <tr>
      <th>2019-03-04</th>
      <td>43.962502</td>
      <td>39.924957</td>
    </tr>
    <tr>
      <th>2019-03-05</th>
      <td>43.882500</td>
      <td>40.033768</td>
    </tr>
    <tr>
      <th>2019-03-06</th>
      <td>43.630001</td>
      <td>40.126617</td>
    </tr>
    <tr>
      <th>2019-03-07</th>
      <td>43.125000</td>
      <td>40.164608</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2021-03-08</th>
      <td>116.360001</td>
      <td>105.168793</td>
    </tr>
    <tr>
      <th>2021-03-09</th>
      <td>121.089996</td>
      <td>104.164322</td>
    </tr>
    <tr>
      <th>2021-03-10</th>
      <td>119.980003</td>
      <td>103.716484</td>
    </tr>
    <tr>
      <th>2021-03-11</th>
      <td>121.959999</td>
      <td>103.439598</td>
    </tr>
    <tr>
      <th>2021-03-12</th>
      <td>121.029999</td>
      <td>103.565666</td>
    </tr>
  </tbody>
</table>
<p>513 rows × 2 columns</p>
</div>




```python
# ошибки
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import max_error
print("MAE", mean_absolute_error(y_test, predictions)) # средняя абсолютная ошибка 
print("MAX", max_error(y_test, predictions)) # максимальная ошибка 
print(rmse)
```

    MAE 10.066354591711688
    MAX 29.74413299560547
    10.057691391913282
    


```python
# Итоги

#1 - модель работает
#2 - модель допукает существенную ошибку в прогнозировании (порядка 10 долларов в среднем)
#3 - решение для #2 это уменьшение периода прогнозирования с 60 дней до 14 или 7 (так range цены будет меньше)
```
